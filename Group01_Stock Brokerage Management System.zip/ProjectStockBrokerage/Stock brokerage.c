/*CSE115 Section 8 Lab Project
Title: Stock Brokerage Management System
Team > Name :Abdur Rahman Yasin
       ID   :2531844042
       Name :Shadman Shawkat Bhuiyan
       ID   :2532920042
       Name :Mahir Sadman
       ID   :2531065642
       Name :Musfiqur Rahman
       ID   :2321503043
*/
#include <stdio.h>
#include <string.h>
#define MAX_CLIENTS 100
#define MAX_STOCKS 20


struct Client {
    int id;
    char name[50];
    char stockName[MAX_STOCKS][50];
    int stockQty[MAX_STOCKS];
    float stockPrice[MAX_STOCKS];
    int stockCount;
};

struct Client clients[MAX_CLIENTS];
int clientCount = 0;

//Function Declaration
int login(void);            //Abdur Rahman Yasin
void LoadingFile(void);     //Abdur Rahman Yasin
void AddnewClient(void);    //Abdur Rahman Yasin

void ViewingClient(void);   //Musfiqur Rahman
void SearchingClient(void); //Musfiqur Rahman


void Edit(void);            //Shadman Shawkat Bhuiyan
void Delete(void);          //Shadman Shawkat Bhuiyan

void SavingFile(void);      //Mahir Sadman
void Save_ClientData(void); //Mahir Sadman


//MAIN FUNCTION (Abdur Rahman Yasin)
int main(void)
{
    int choice;

    LoadingFile();

    if (!login())
    {
        printf("\nLogin Failed!\n Exiting program....\n");
        return 0;
    }

    do {
        printf("\n Stock Brokerage Management System   \n");
        printf("1. View Clients\n");
        printf("2. Add Client\n");
        printf("3. Search Client\n");
        printf("4. Edit Client\n");
        printf("5. Delete Client\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1: ViewingClient();
            break;
            case 2: AddnewClient();
            break;
            case 3: SearchingClient();
            break;
            case 4: Edit();
            break;
            case 5: Delete();
            break;
            case 6: printf("Exiting...\n");
            break;
            default: printf("Invalid choice\n");
        }
    } while (choice != 6);

    return 0;
}

//Login Function
int login(void)
{
    char user[20], pass[20];
    char fileUser[20], filePass[20];

    FILE *fp = fopen("login.txt", "r");


    fscanf(fp, "%s %s", fileUser, filePass);
    fclose(fp);

    printf("\nLOGIN REQUIRED      \n\n");
    printf("Enter Username: ");
    scanf("%s", user);
    printf("Enter Password: ");
    scanf("%s", pass);

    return (strcmp(user, fileUser) == 0 && strcmp(pass, filePass) == 0);
}

//File Loading Function
void LoadingFile(void)
{
    FILE *fp = fopen("clients_details.txt", "r");
    if (!fp) return;

    fscanf(fp, "%d", &clientCount);

    for (int i = 0; i < clientCount; i++)
    {
        fscanf(fp, "%d", &clients[i].id);
        fscanf(fp, " %[^\n]", clients[i].name);
        fscanf(fp, "%d", &clients[i].stockCount);

        for (int j = 0; j < clients[i].stockCount; j++)
        {
            fscanf(fp, " %[^\n]", clients[i].stockName[j]);
            fscanf(fp, "%d", &clients[i].stockQty[j]);
            fscanf(fp, "%f", &clients[i].stockPrice[j]);
        }
    }
    fclose(fp);
}

//Saves the file
void SavingFile(void)
{
    FILE *fp = fopen("clients_details.txt", "w");
    if (!fp)
    {
        printf("Error opening file for saving\n");
        return;
    }

    /* Save client count */
    fprintf(fp, "%d\n", clientCount);

    for (int i = 0; i < clientCount; i++)
    {
        fprintf(fp, "%d\n", clients[i].id);
        fprintf(fp, "%s\n", clients[i].name);
        fprintf(fp, "%d\n", clients[i].stockCount);

        for (int j = 0; j < clients[i].stockCount; j++)
        {
            fprintf(fp, "%s\n", clients[i].stockName[j]);
            fprintf(fp, "%d\n", clients[i].stockQty[j]);
            fprintf(fp, "%f\n", clients[i].stockPrice[j]);
        }
    }

    fclose(fp);
}

//Adds a new client to the array and saves it to file
void AddnewClient(void)
{

    struct Client c;

    printf("Enter client ID: ");
    scanf("%d", &c.id);

    printf("Enter client name: ");
    scanf(" %[^\n]", c.name);

    printf("Enter Stock Count:  ");
    scanf("%d", &c.stockCount);

    for (int i = 0; i < c.stockCount; i++)
{
    printf("Stock %d name: ", i + 1);
    scanf(" %[^\n]", c.stockName[i]);

    do
    {
        printf("Quantity: ");
        scanf("%d", &c.stockQty[i]);
    } while (c.stockQty[i] < 0);

    do
    {
        printf("Price: ");
        scanf("%f", &c.stockPrice[i]);
    } while (c.stockPrice[i] < 0);
}


    clients[clientCount++] = c;
    SavingFile();
    Save_ClientData();
    printf("CLIENT ADDED SUCCESSFULLY\n");
}

//Client Viewing Function
void ViewingClient(void)
{
    if (clientCount == 0)
    {
        printf("No clients available.\n");
        return;
    }

    for (int i = 0; i < clientCount; i++)
    {
        printf("\nClient ID: %d\n", clients[i].id);
        printf("Name: %s\n", clients[i].name);
        printf("Stocks (%d):\n", clients[i].stockCount);

        float totalValue = 0;
        for (int j = 0; j < clients[i].stockCount; j++)
        {
            printf("  %s - Qty: %d - Price: %.2f\n",
                   clients[i].stockName[j],
                   clients[i].stockQty[j],
                   clients[i].stockPrice[j]);
            totalValue += clients[i].stockQty[j] * clients[i].stockPrice[j];
        }
        printf("Total Portfolio Value: %.2f\n", totalValue);
    }
}

//Client Searching Function
//Currently searching by name only, ID search can be added later

void SearchingClient(void)
{
    char key[50];
    int found = 0;

    printf("Enter name to search: ");
    scanf(" %[^\n]", key);

    for (int i = 0; i < clientCount; i++)
    {
        if (strstr(clients[i].name, key))
        {
            printf("\nClient ID: %d\n", clients[i].id);
            printf("Name: %s\n", clients[i].name);
            printf("Stocks (%d):\n", clients[i].stockCount);

            float totalValue = 0;
            for (int j = 0; j < clients[i].stockCount; j++)
            {
                printf("  %s - Qty: %d - Price: %.2f\n",
                       clients[i].stockName[j],
                       clients[i].stockQty[j],
                       clients[i].stockPrice[j]);

                totalValue += clients[i].stockQty[j] * clients[i].stockPrice[j];
            }

            printf("Total Portfolio Value: %.2f\n", totalValue);
            found = 1;
        }
    }

    if (!found)
        printf("No Matching Client Found.\n");
}

//Client Editing Function
void Edit(void)
{
    int id, found = -1;

    printf("Enter Client ID to edit: ");
    scanf("%d", &id);

    for (int i = 0; i < clientCount; i++)
    {
        if (clients[i].id == id)
        {
            found = i;
            break;
        }
    }

    if (found == -1)
    {
        printf("Client not found\n");
        return;
    }

    printf("New name: ");
    scanf(" %[^\n]", clients[found].name);

    printf("New Stock Count: ");
    scanf("%d", &clients[found].stockCount);

    for (int j = 0; j < clients[found].stockCount; j++)
    {
        printf("Stock %d Name: ", j + 1);
        scanf(" %[^\n]", clients[found].stockName[j]);
        printf("Quantity: ");
        scanf("%d", &clients[found].stockQty[j]);
        printf("Price: ");
        scanf("%f", &clients[found].stockPrice[j]);
    }

    SavingFile();
    Save_ClientData();
    printf("RECORD UPDATED SUCCESSFULLY\n");
}

//Client Deleting Function
//This function wont delete the data from "clientdata.txt" file
void Delete(void)
{
    int id, index = -1;

    printf("Enter Client ID to Delete: ");
    scanf("%d", &id);

    for (int i = 0; i < clientCount; i++)
    {
        if (clients[i].id == id)
        {
            index = i;
            break;
        }
    }

    if (index == -1)
    {
        printf("Client not found\n");
        return;
    }

    for (int i = index; i < clientCount - 1; i++)
        clients[i] = clients[i + 1];

    clientCount--;
    SavingFile();
    printf("CLIENT DELETED SUCCESSFULLY\n");
}

/*Saving Client Data to "clientdata.txt" file*/
void Save_ClientData(void)
{
    FILE *fp = fopen("clientdata.txt", "w");
    if (!fp)
    {
        printf("File could not be opened.\n");
        return;
    }

    fprintf(fp, "Client Count: %d\n", clientCount);

    for (int i = 0; i < clientCount; i++)
    {
        fprintf(fp, "\n\nClient ID: %d\n", clients[i].id);
        fprintf(fp, "Client Name: %s\n", clients[i].name);
        fprintf(fp, "Stock Count: %d\n", clients[i].stockCount);


        for (int j = 0; j < clients[i].stockCount; j++)
        {
            fprintf(fp, "Stock Name: %s\n", clients[i].stockName[j]);
            fprintf(fp, "Stock Quantity: %d\n", clients[i].stockQty[j]);
            fprintf(fp, "Stock Price: %.2f\n\n", clients[i].stockPrice[j]);

        }

    }

    fclose(fp);
}
