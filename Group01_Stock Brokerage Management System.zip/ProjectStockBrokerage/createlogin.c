#include <stdio.h>

int main(void)
{
    FILE *fp;
    char username[20], password[20];

    fp = fopen("login.txt", "w");
    if (fp == NULL)
    {
        printf("Error creating login file!\n");
        return 1;
    }

    printf("Create Login Credentials\n");
    printf("\n\n");

    printf("Enter username: ");
    scanf("%s", username);

    printf("Enter password: ");
    scanf("%s", password);

    fprintf(fp, "%s %s", username, password);

    fclose(fp);

    printf("\nLogin credentials saved successfully!\n");

    return 0;
}

